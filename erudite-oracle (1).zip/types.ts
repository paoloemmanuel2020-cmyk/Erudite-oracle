
export type Category = 'Physics' | 'Philosophy' | 'Mathematics' | 'Culture' | 'Linguistics' | 'Biology';
