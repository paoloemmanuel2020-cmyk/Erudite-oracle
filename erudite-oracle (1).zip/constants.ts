
import { Category } from './types';

export const CATEGORIES: Category[] = [
  'Physics',
  'Philosophy',
  'Mathematics',
  'Culture',
  'Linguistics',
  'Biology',
];
